export enum Links {
  line = "/icons/line.svg",
  logo = "/images/logo.svg",
  logoHeader = "/icons/barca.svg",
  rightDecorators = "/images/rightDecorators.svg",
  leftDecorators = "/images/leftDecorators.svg",
}
