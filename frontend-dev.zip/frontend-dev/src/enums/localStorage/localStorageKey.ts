export enum LocalStorageKey {
  AccessToken = "at",
  RefreshToken = "rt",
  AcceptCookie = "accept_cookie",
}
