import { RegisterPage } from "@pages/RegisterPage";
import { AppRoutes, Routes } from "@enums/routes";
import { RouteProps } from "react-router-dom";
import { LoginPage } from "@pages/LoginPage";
import { MainPage } from "@pages/MainPage";
import { ForgotPasswordPage } from "@pages/ForgotPasswordPage";
import { ConfirmPasswordPage } from "@pages/ConfirmPasswordPage";

export const RoutePath: Record<AppRoutes, string> = {
  [AppRoutes.MAIN]: Routes.MAIN,
  [AppRoutes.LOGIN]: Routes.LOGIN,
  [AppRoutes.REGISTER]: Routes.REGISTER,
  [AppRoutes.SHOP]: Routes.SHOP,
  [AppRoutes.ABOUT_US]: Routes.ABOUT_US,
  [AppRoutes.ABOUT_US_PROJECT]: Routes.ABOUT_US_PROJECT,
  [AppRoutes.ABOUT_US_COACHES]: Routes.ABOUT_US_COACHES,
  [AppRoutes.ABOUT_US_PRICE_CONTRACT]: Routes.ABOUT_US_PRICE_CONTRACT,
  [AppRoutes.ABOUT_US_ADDITIONAL_SERVICES]: Routes.ABOUT_US_ADDITIONAL_SERVICES,
  [AppRoutes.ARTICLES]: Routes.ARTICLES,
  [AppRoutes.SERVICES]: Routes.SERVICES,
  [AppRoutes.SERVICES_CAFE]: Routes.SERVICES_CAFE,
  [AppRoutes.JALAL_ABAD]: Routes.JALAL_ABAD,
  [AppRoutes.BISHKEK]: Routes.BISHKEK,
  [AppRoutes.CLINICS]: Routes.CLINICS,
  [AppRoutes.COMPETITIONS]: Routes.COMPETITIONS,
  [AppRoutes.FORGOT_PASSWORD]: Routes.FORGOT_PASSWORD,
  [AppRoutes.CONFIRM_PASSWORD]: Routes.CONFIRM_PASSWORD,
};

export const routeConfig: Record<AppRoutes, RouteProps> = {
  [AppRoutes.MAIN]: {
    path: RoutePath.main,
    element: <MainPage />,
  },
  [AppRoutes.LOGIN]: {
    path: RoutePath.login,
    element: <LoginPage />,
  },
  [AppRoutes.REGISTER]: {
    path: RoutePath.register,
    element: <RegisterPage />,
  },
  [AppRoutes.SHOP]: {},
  [AppRoutes.ABOUT_US]: {},
  [AppRoutes.ABOUT_US_PROJECT]: {},
  [AppRoutes.ABOUT_US_COACHES]: {},
  [AppRoutes.ABOUT_US_PRICE_CONTRACT]: {},
  [AppRoutes.ABOUT_US_ADDITIONAL_SERVICES]: {},
  [AppRoutes.ARTICLES]: {},
  [AppRoutes.SERVICES]: {},
  [AppRoutes.SERVICES_CAFE]: {},
  [AppRoutes.JALAL_ABAD]: {},
  [AppRoutes.BISHKEK]: {},
  [AppRoutes.CLINICS]: {},
  [AppRoutes.COMPETITIONS]: {},
  [AppRoutes.FORGOT_PASSWORD]: {
    path: RoutePath["forgot-password"],
    element: <ForgotPasswordPage />,
  },
  [AppRoutes.CONFIRM_PASSWORD]: {
    path: RoutePath["forget-password"],
    element: <ConfirmPasswordPage />,
  },
};
