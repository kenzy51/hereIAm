import { AppRoutes, Routes } from "@enums/routes";

export const RoutePath: Record<AppRoutes, string> = {
  [AppRoutes.MAIN]: Routes.MAIN,
  [AppRoutes.LOGIN]: Routes.LOGIN,
  [AppRoutes.REGISTER]: Routes.REGISTER,
  [AppRoutes.SHOP]: Routes.SHOP,
  [AppRoutes.ABOUT_US]: Routes.ABOUT_US,
  [AppRoutes.ABOUT_US_PROJECT]: Routes.ABOUT_US_PROJECT,
  [AppRoutes.ABOUT_US_COACHES]: Routes.ABOUT_US_COACHES,
  [AppRoutes.ABOUT_US_PRICE_CONTRACT]: Routes.ABOUT_US_PRICE_CONTRACT,
  [AppRoutes.ABOUT_US_ADDITIONAL_SERVICES]: Routes.ABOUT_US_ADDITIONAL_SERVICES,
  [AppRoutes.ARTICLES]: Routes.ARTICLES,
  [AppRoutes.SERVICES]: Routes.SERVICES,
  [AppRoutes.SERVICES_CAFE]: Routes.SERVICES_CAFE,
  [AppRoutes.JALAL_ABAD]: Routes.JALAL_ABAD,
  [AppRoutes.BISHKEK]: Routes.BISHKEK,
  [AppRoutes.CLINICS]: Routes.CLINICS,
  [AppRoutes.COMPETITIONS]: Routes.COMPETITIONS,
  [AppRoutes.FORGOT_PASSWORD]: Routes.FORGOT_PASSWORD,
  [AppRoutes.CONFIRM_PASSWORD]: Routes.CONFIRM_PASSWORD,
};
