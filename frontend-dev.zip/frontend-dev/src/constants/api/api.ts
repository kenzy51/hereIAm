export const AuthApi = {
  Login: "/user/auth/login",
  Register: "/user/auth/register",
  SendCode: "/user/auth/verification-code",
  CheckCode: "/user/auth/verify-email",
  ForgotPassword: "/user/auth/reset-password/link",
  ConfirmPassword: "/user/auth/reset-password",
  Logout: "/user/auth/logout",
  Profile: "/user/profile",
};
