export const SliceConstants = {
  SignIn: "barcaSlice/signin",
  SignUp: "barcaSlice/signup",
  SendCode: "barcaSlice/sendCode",
  CheckCode: "barcaSlice/checkCode",
  ForgotPassword: "barcaSlice/forgotPassword",
  ConfirmPassword: "barcaSlice/confirmPassword",
  GetProfile: "barcaSlice/profile",
  Logout: "barcaSlice/logout",
};

export const SliceName = {
  Auth: "auth",
  Barca: "barca",
};
