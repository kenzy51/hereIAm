export const ImagesAlt = "Error";
