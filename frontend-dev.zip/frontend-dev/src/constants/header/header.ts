import { Routes } from "@enums/routes";

export const ABOUT_US_ITEMS = [
  { key: 1, href: Routes.ABOUT_US_PROJECT, label: "aboutUs.menu.project" },
  {
    key: 2,
    href: Routes.ABOUT_US_PRICE_CONTRACT,
    label: "aboutUs.menu.price_contract",
  },
  { key: 3, href: Routes.ABOUT_US_COACHES, label: "aboutUs.menu.coaches" },
  {
    key: 4,
    href: Routes.ABOUT_US_ADDITIONAL_SERVICES,
    label: "aboutUs.menu.add_services",
  },
];

export const ARTICLES_ITEMS = [
  { key: 1, href: Routes.ARTICLES, label: "articles.menu.news" },
];

export const SERVICES_ITEMS = [
  {
    key: 1,
    href: Routes.SERVICES_CAFE,
    label: "services.menu.cafe",
  },
];

export const BARCA_EXP_ITEMS = [
  {
    key: 1,
    href: Routes.JALAL_ABAD,
    label: "offices.menu.jalal_adab",
  },
  { key: 2, href: Routes.BISHKEK, label: "offices.menu.bishkek" },
];
