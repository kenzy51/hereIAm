export const CODE_LENGTH = 7;
export const RESEND_TIME = 60;
