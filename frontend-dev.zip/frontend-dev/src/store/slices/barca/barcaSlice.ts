import { AuthApi } from "@constants/api";
import { SliceConstants, SliceName } from "@constants/slices";
import { LocalStorageKey } from "@enums/localStorage";
import { Routes } from "@enums/routes";
import { LocalStorage } from "@localStorage/localStorage";
import {
  CheckCode,
  ConfirmSendPasswordType,
  ForgotPasswordType,
  SendCode,
  SignInType,
  SignSendUpType,
} from "@models/login";
import { PayloadAction, createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { makeAuthorization } from "@store/authorization";
import axios from "axios";

const BASE_URL = process.env.REACT_APP_BASE_URL;

export interface BarcaState {
  loading: boolean;
  email: string;
  password: string;
  emailConfirm: boolean;
  profile: {
    id: string;
    name: string;
    lastname: string;
    email: string;
  };
}

const initialState: BarcaState = {
  loading: false,
  email: "",
  password: "",
  emailConfirm: false,
  profile: {
    id: "",
    name: "",
    lastname: "",
    email: "",
  },
};

export const signIn = createAsyncThunk(
  SliceConstants.SignIn,
  async function (
    {
      values: props,
      navigate,
      setAlert,
    }: { values: SignInType; navigate: any; setAlert: any },
    { rejectWithValue }
  ) {
    try {
      const { data } = await axios.post(BASE_URL + AuthApi.Login, props);
      LocalStorage.setItem(
        LocalStorageKey.AccessToken,
        JSON.stringify(data.accessToken)
      );
      navigate(Routes.MAIN);
      return data;
    } catch (error: any) {
      setAlert(error.response.data.message, "error");
      return rejectWithValue(error);
    }
  }
);

export const getProfile = createAsyncThunk(
  SliceConstants.GetProfile,
  async function (_, { rejectWithValue }) {
    try {
      const { data } = await axios.get(
        BASE_URL + AuthApi.Profile,
        makeAuthorization()
      );
      return data;
    } catch (error: any) {
      return rejectWithValue(error);
    }
  }
);

export const logout = createAsyncThunk(
  SliceConstants.Logout,
  async function (_, { rejectWithValue }) {
    try {
      const { data } = await axios.post(
        BASE_URL + AuthApi.Logout,
        null,
        makeAuthorization()
      );
      LocalStorage.clear();
      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const sendCode = createAsyncThunk(
  SliceConstants.SendCode,
  async function (props: SendCode, { rejectWithValue }) {
    try {
      const { data } = await axios.post(BASE_URL + AuthApi.SendCode, props);
      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const checkCode = createAsyncThunk(
  SliceConstants.CheckCode,
  async function (props: CheckCode, { rejectWithValue }) {
    try {
      const { data } = await axios.post(BASE_URL + AuthApi.CheckCode, props);
      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const signUp = createAsyncThunk(
  SliceConstants.SignUp,
  async function ({
    values: props,
    navigate,
    setAlert,
  }: {
    values: SignSendUpType;
    navigate: any;
    setAlert: any;
  }) {
    try {
      const { data } = await axios.post(BASE_URL + AuthApi.Register, props);
      navigate(Routes.MAIN);
      LocalStorage.setItem(
        LocalStorageKey.AccessToken,
        JSON.stringify(data.accessToken)
      );
      return data;
    } catch (error: any) {
      setAlert(error.response.data.message, "error");
      return null;
    }
  }
);

export const forgotPassword = createAsyncThunk(
  SliceConstants.ForgotPassword,
  async function (
    { values: props, navigate }: { values: ForgotPasswordType; navigate: any },
    { rejectWithValue }
  ) {
    try {
      const { data } = await axios.post(
        BASE_URL + AuthApi.ForgotPassword,
        props
      );
      navigate(Routes.CONFIRM_PASSWORD);
      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const confirmPassword = createAsyncThunk(
  SliceConstants.ConfirmPassword,
  async function (
    {
      values: props,
      navigate,
    }: { values: ConfirmSendPasswordType; navigate: any },
    { rejectWithValue }
  ) {
    try {
      const { data } = await axios.post(
        BASE_URL + AuthApi.ConfirmPassword,
        props
      );
      navigate(Routes.LOGIN);
      LocalStorage.setItem(
        LocalStorageKey.AccessToken,
        JSON.stringify(data.accessToken)
      );
      return data;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

const barcaSlice = createSlice({
  name: SliceName.Barca,
  initialState,
  reducers: {
    setEmail: (state, action: PayloadAction<string>) => {
      return {
        ...state,
        email: action.payload,
      };
    },
    setPassword: (state, action: PayloadAction<string>) => {
      return {
        ...state,
        password: action.payload,
      };
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getProfile.fulfilled, (state, { payload }) => {
      return {
        ...state,
        profile: payload,
      };
    });
    builder.addCase(getProfile.rejected, (state) => {
      return {
        ...state,
        profile: {
          id: "",
          name: "",
          lastname: "",
          email: "",
        },
      };
    });
    builder.addCase(checkCode.fulfilled, (state, { payload }) => {
      return {
        ...state,
        emailConfirm: payload.success,
      };
    });
    builder.addCase(checkCode.rejected, (state) => {
      return {
        ...state,
        emailConfirm: false,
      };
    });
  },
});

export const { setEmail, setPassword } = barcaSlice.actions;

export default barcaSlice.reducer;
