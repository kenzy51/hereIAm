export * from "./barcaSlice";
