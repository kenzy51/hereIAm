import { createSelector } from "@reduxjs/toolkit";
import { BarcaState } from "@store/slices";

type WithbarcaState = {
  barca: BarcaState;
};

export const barcaStateSelector = (state: WithbarcaState): BarcaState =>
  state.barca;

export const getEmailSelector = createSelector(
  barcaStateSelector,
  (barcaSliceState) => {
    return barcaSliceState.email;
  }
);

export const getPasswordSelector = createSelector(
  barcaStateSelector,
  (barcaSliceState) => {
    return barcaSliceState.password;
  }
);

export const getProfileSelector = createSelector(
  barcaStateSelector,
  (barcaSliceState) => {
    return barcaSliceState.profile;
  }
);

export const getEmailConfirmSelector = createSelector(
  barcaStateSelector,
  (barcaSliceState) => {
    return barcaSliceState.emailConfirm;
  }
);
