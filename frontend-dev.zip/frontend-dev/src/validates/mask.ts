export const codeMask = [/\d/, /\d/, /\d/, "-", /\d/, /\d/, /\d/];
