import React from "react";
import { Button } from "antd";
import { useTranslation } from "react-i18next";
import styles from "./CookiesPopup.module.scss";

type PropsType = {
  acceptCookitFunc: () => void;
};

export const CookiesPopup: React.FC<PropsType> = ({ acceptCookitFunc }) => {
  const { t } = useTranslation();

  return (
    <div className={styles.block}>
      <div className={styles.content}>
        <div className={styles.title}>{t("cookie.title")}</div>
        <div className={styles.desc}>{t("cookie.desc")}</div>
        <div className={styles.btnBlock}>
          <Button className={styles.btn} onClick={acceptCookitFunc}>
            {t("cookie.btn")}
          </Button>
        </div>
      </div>
    </div>
  );
};
