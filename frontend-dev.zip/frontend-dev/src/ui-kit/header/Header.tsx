import { Layout } from "antd";
import { Link, useLocation } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { AppRoutes, Routes } from "@enums/routes";
import { Links } from "@enums/links";
import cn from "classnames";
import {
  ABOUT_US_ITEMS,
  SERVICES_ITEMS,
  ARTICLES_ITEMS,
  BARCA_EXP_ITEMS,
} from "@constants/header";
import { IMenuItem, getLink } from "@utils/getLink";
import { getProfile } from "@store/slices";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { HeaderMenu } from "./components";
import { Breadcrumbs } from "./components/Breadcrumbs";
import { LoginHeader } from "./components/loginHeader";
import styles from "./Header.module.scss";

export const Header = () => {
  const { pathname } = useLocation();
  const { t } = useTranslation();
  const [isHeaderHidden, setHeaderHidden] = useState(false);
  const [prevScrollY, setPrevScrollY] = useState(0);
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(getProfile());
  }, []);

  const generateMenuItems = (items: IMenuItem[]) => {
    return items.map((item) => getLink(item.key, item.href, t(item.label)));
  };

  const ABOUT_US: IMenuItem[] = generateMenuItems(ABOUT_US_ITEMS);
  const ARTICLES: IMenuItem[] = generateMenuItems(ARTICLES_ITEMS);
  const SERVICES: IMenuItem[] = generateMenuItems(SERVICES_ITEMS);
  const BARCA_EXP: IMenuItem[] = generateMenuItems(BARCA_EXP_ITEMS);

  const SUB_MENU: Record<string, IMenuItem[]> = {
    [AppRoutes.ABOUT_US]: ABOUT_US,
    [AppRoutes.ARTICLES]: ARTICLES,
    [AppRoutes.SERVICES]: SERVICES,
    [AppRoutes.BISHKEK]: BARCA_EXP,
    [AppRoutes.JALAL_ABAD]: BARCA_EXP,
  };

  const subMenu = useMemo(() => SUB_MENU[pathname.split("/")[1]], [pathname]);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY > prevScrollY) {
        setHeaderHidden(true);
      } else {
        setHeaderHidden(false);
      }
      setPrevScrollY(currentScrollY);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [prevScrollY]);

  return (
    <Layout.Header
      className={cn(styles.header, {
        [styles.hide]: pathname !== Routes.MAIN && isHeaderHidden,
      })}
    >
      <div className={styles.nav_top}>
        <LoginHeader />
      </div>
      <div className={styles.nav_middle}>
        <Link to={Routes.MAIN} className={styles.logo}>
          <img src={Links.logo} alt="logo" width={130} height={44} />
        </Link>
        <div className={styles.menu}>
          <div className={styles.menu_left}>
            <HeaderMenu
              items={ABOUT_US}
              path={Routes.ABOUT_US}
              label={t("aboutUs.title")}
            />
            <HeaderMenu
              items={ARTICLES}
              path={Routes.ARTICLES}
              label={t("articles.title")}
            />
          </div>
          <div className={styles.menu_right}>
            <HeaderMenu
              items={BARCA_EXP}
              path={
                pathname.includes(Routes.BISHKEK)
                  ? Routes.BISHKEK
                  : Routes.JALAL_ABAD
              }
              label={t("offices.title")}
            />
            <HeaderMenu
              items={SERVICES}
              path={Routes.SERVICES}
              label={t("services.title")}
            />
            <HeaderMenu path={Routes.SHOP} label={t("shop")} />
          </div>
        </div>
      </div>
      <Breadcrumbs menu={subMenu} />
    </Layout.Header>
  );
};
