import { RegisterLayout } from "@features/layout";

export const RegisterPage = () => {
  return <RegisterLayout />;
};
