export * from "./MainPage";
