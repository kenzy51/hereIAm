import { MainLayout } from "@features/layout";

export const MainPage = () => {
  return <MainLayout />;
};
