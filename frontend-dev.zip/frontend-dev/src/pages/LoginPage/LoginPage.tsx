import { LoginLayout } from "@features/layout";

export const LoginPage = () => {
  return <LoginLayout />;
};
