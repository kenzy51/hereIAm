import { ForgotPasswordLayout } from "@features/layout";

export const ForgotPasswordPage = () => {
  return <ForgotPasswordLayout />;
};
