import { ConfirmPasswordLayout } from "@features/layout";

export const ConfirmPasswordPage = () => {
  return <ConfirmPasswordLayout />;
};
