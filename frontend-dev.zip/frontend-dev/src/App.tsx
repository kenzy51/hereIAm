import { Suspense, useEffect, useState } from "react";
import { Spin } from "antd";
import { Header } from "@ui-kit/header";
import { useLocation } from "react-router-dom";
import { CookiesPopup } from "@ui-kit/cookiesPopup";
import { AppRouter } from "./providers";
import { LocalStorageKey, Routes } from "./enums";
import { LocalStorage } from "./localStorage";

export default function App() {
  const { pathname } = useLocation();
  const excludedPaths = [
    Routes.LOGIN,
    Routes.REGISTER,
    Routes.FORGOT_PASSWORD,
    Routes.CONFIRM_PASSWORD,
  ];
  const acceptCookie = LocalStorage.getItem(LocalStorageKey.AcceptCookie);
  const [cookie, setCookie] = useState(acceptCookie || "true");

  const acceptCookitFunc = () => {
    LocalStorage.setItem(LocalStorageKey.AcceptCookie, "true");
    setCookie("true");
  };

  useEffect(() => {
    if (!acceptCookie) {
      setTimeout(() => {
        LocalStorage.setItem(LocalStorageKey.AcceptCookie, "false");
        setCookie("false");
      }, 3 * 1000);
    }
  }, []);

  return (
    <Suspense fallback={<Spin />}>
      {!excludedPaths.includes(pathname as Routes) && <Header />}
      <div style={{ marginTop: 125 }}>
        <AppRouter />
      </div>
      {cookie !== "true" && (
        <CookiesPopup acceptCookitFunc={acceptCookitFunc} />
      )}
    </Suspense>
  );
}
