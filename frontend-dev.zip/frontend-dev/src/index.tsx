import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { AlertProvider } from "@contexts/AlertContext";
import { AlertPopup } from "@ui-kit/alertPopup";
import { store } from "./store";
import App from "./App";
import "./fonts/Montserrat-250.ttf";
import "./fonts/Montserrat-600.ttf";
import "./fonts/Montserrat-400.ttf";
import "./fonts/Montserrat-italic-600.ttf";
import "./index.css";
import "@theme/index.scss";
import "./i18n";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);

root.render(
  <React.StrictMode>
    <Provider store={store}>
      <BrowserRouter>
        <AlertProvider>
          <>
            <App />
            <AlertPopup />
          </>
        </AlertProvider>
      </BrowserRouter>
    </Provider>
  </React.StrictMode>
);
