import React from "react";
import { Button, Form, Row } from "antd";
import { useTranslation } from "react-i18next";
import { FormInput } from "@ui-kit/formInput";
import { useRegister, useShowCodeModal } from "@features/auth/hooks";
import { getEmailConfirmSelector } from "@store/selectors";
import { validatePassword } from "@validates/codeValidates";
import { useAppSelector } from "@hooks/useAppSelector";
import styles from "./Forms.module.scss";

export const Forms: React.FC = () => {
  const { t } = useTranslation();
  const { onOpen, email } = useShowCodeModal();
  const { password } = useRegister();
  const emailConfirm = useAppSelector(getEmailConfirmSelector);

  const compareToFirstPassword = (_: any, value: string) => {
    if (value && value !== password) {
      // eslint-disable-next-line prefer-promise-reject-errors
      return Promise.reject("Пароли не совпадают");
    }
    return Promise.resolve();
  };

  return (
    <>
      <Form.Item name="name">
        <FormInput allowClear placeholder={t("register.name")} />
      </Form.Item>

      <Form.Item name="lastname">
        <FormInput allowClear placeholder={t("register.username")} />
      </Form.Item>

      <Form.Item
        name="email"
        className={email && styles.emailForm}
        rules={[
          {
            required: true,
            message: "Пожалуйста, введите email",
          },
          {
            type: "email",
            message: "Введите корректный email",
          },
        ]}
      >
        <FormInput allowClear placeholder={t("login.email")} />
      </Form.Item>

      {email && !emailConfirm && (
        <Row className={styles.btnRow}>
          <Button onClick={onOpen} className={styles.btn}>
            {t("register.confirmEmail")}
          </Button>
        </Row>
      )}

      <Form.Item
        name="password"
        rules={[
          {
            required: true,
            message: "Пожалуйста, введите пароль",
          },
          {
            validator: validatePassword,
          },
        ]}
      >
        <FormInput
          allowClear
          type="password"
          placeholder={t("login.password")}
        />
      </Form.Item>

      <Form.Item
        name="confirmPassword"
        rules={[
          {
            required: true,
            message: "Пожалуйста, подтвердите пароль",
          },
          {
            validator: compareToFirstPassword,
          },
        ]}
      >
        <FormInput
          allowClear
          type="password"
          placeholder={t("register.confirmPassword")}
        />
      </Form.Item>
    </>
  );
};
