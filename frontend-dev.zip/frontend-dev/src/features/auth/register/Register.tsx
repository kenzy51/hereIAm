import React from "react";
import { Form } from "antd";
import { SignUpType } from "@models/login";
import { Trans } from "react-i18next";
import { FormLayout } from "../layout";
import { useRegister, useShowCodeModal } from "../hooks";
import { SubmitButton } from "../components";
import { Forms } from "./forms";
import { ConfirmEmailModal } from "../modals/ConfirmEmailModal";
import styles from "./Register.module.scss";

export const Register: React.FC = () => {
  const { form, onFinish, onFinishFailed } = useRegister();
  const { onClose } = useShowCodeModal();

  return (
    <FormLayout>
      <Form<SignUpType>
        onFinish={onFinish}
        autoComplete="off"
        onFinishFailed={onFinishFailed}
        className={styles.form}
        layout="vertical"
        form={form}
      >
        <Forms />
        <SubmitButton form={form}>
          <Trans i18nKey="register.submit" />
        </SubmitButton>
      </Form>
      <ConfirmEmailModal onClose={onClose} />
    </FormLayout>
  );
};
