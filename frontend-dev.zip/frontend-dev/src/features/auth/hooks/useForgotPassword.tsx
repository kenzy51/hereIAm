import { useCallback, useEffect } from "react";
import { ValidateErrorEntity } from "rc-field-form/lib/interface";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { ForgotPasswordType } from "@models/login";
import { AppDispatch } from "@store/index";
import { forgotPassword, setEmail } from "@store/slices/barca/barcaSlice";
import { Form, FormInstance } from "antd";

type ReturnType = {
  form: FormInstance;
  onFinish: (values: ForgotPasswordType) => void;
  onFinishFailed: (errorInfo: ValidateErrorEntity<ForgotPasswordType>) => void;
};

export const useForgotPassword = (): ReturnType => {
  const [form] = Form.useForm();
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const email = Form.useWatch("email", form);

  useEffect(() => {
    if (email) {
      dispatch(setEmail(email));
    }
  }, [email]);

  const onFinish = useCallback(
    (values: ForgotPasswordType) => {
      dispatch(forgotPassword({ values, navigate }));
    },
    [dispatch]
  );

  const onFinishFailed = useCallback(
    (errorInfo: ValidateErrorEntity<ForgotPasswordType>) => {
      console.log("Failed:", errorInfo);
    },
    []
  );

  return {
    form,
    onFinish,
    onFinishFailed,
  };
};
