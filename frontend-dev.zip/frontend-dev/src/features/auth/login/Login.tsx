import React from "react";
import { SignInType } from "@models/login";
import { Form } from "antd";
import { Trans } from "react-i18next";
import { SubmitButton } from "../components";
import { useLogin } from "../hooks";
import { FormLayout } from "../layout";
import { Forms } from "./forms";
import { ForgotPassword } from "./forgotPassword";
import styles from "./Login.module.scss";

export const Login: React.FC = () => {
  const { form, onFinish, onFinishFailed } = useLogin();

  return (
    <FormLayout>
      <Form<SignInType>
        onFinish={onFinish}
        autoComplete="off"
        className={styles.form}
        onFinishFailed={onFinishFailed}
        layout="vertical"
        form={form}
      >
        <Forms />
        <SubmitButton form={form}>
          <Trans i18nKey="login.submit" />
        </SubmitButton>
        <ForgotPassword />
      </Form>
    </FormLayout>
  );
};
