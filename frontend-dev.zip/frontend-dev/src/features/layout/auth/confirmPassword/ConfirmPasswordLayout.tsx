import { Typography } from "antd";
import { useTranslation } from "react-i18next";
import { ConfirmPassword } from "@features/auth";
import { AuthFormLayout } from "@ui-kit/layouts";
import styles from "./ConfirmPasswordLayout.module.scss";

export const ConfirmPasswordLayout = () => {
  const { t } = useTranslation();
  return (
    <AuthFormLayout>
      <Typography.Title className={styles.loginTitle}>
        {t("forgotPassword.title")}
      </Typography.Title>
      <ConfirmPassword />
    </AuthFormLayout>
  );
};
