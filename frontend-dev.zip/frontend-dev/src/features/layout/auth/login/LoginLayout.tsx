import { Typography } from "antd";
import { useTranslation } from "react-i18next";
import { Login } from "@features/auth";
import { AuthFormLayout } from "@ui-kit/layouts";
import styles from "./LoginLayout.module.scss";

export const LoginLayout = () => {
  const { t } = useTranslation();
  return (
    <AuthFormLayout>
      <Typography.Title className={styles.loginTitle}>
        {t("login.title")}
      </Typography.Title>
      <Login />
    </AuthFormLayout>
  );
};
