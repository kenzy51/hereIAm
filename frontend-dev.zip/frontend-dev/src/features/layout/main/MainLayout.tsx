export const MainLayout = () => {
  return <div>Main Page</div>;
};
